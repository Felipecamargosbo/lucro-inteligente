// Dados FICTÍCIOS usados apenas para demonstrar a interface.
// Nenhuma conexão real com marketplaces existe neste protótipo.
// Quando as APIs forem integradas, basta trocar a origem em src/services.

import type {
  AlteracaoPreco,
  Anuncio,
  CanalNotificacao,
  CanalRecuperacao,
  ItemEstoque,
  ItemEstoqueDetalhado,
  LogAlteracao,
  Marketplace,
  MarketplaceId,
  Notificacao,
  OportunidadeRecuperacao,
  Pedido,
  Promocao,
  StatusOportunidadeRecuperacao,
  StatusPedido,
  TipoOportunidadeRecuperacao,
  Usuario,
} from "@/types";

/** Gerador pseudoaleatório com semente: os dados são sempre os mesmos. */
function criarRandom(semente: number) {
  let s = semente;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

export const MARKETPLACES: Marketplace[] = [
  {
    id: "mercado-livre",
    nome: "Mercado Livre",
    conectado: true,
    statusConexao: "conectado",
    ultimaSincronizacao: new Date(Date.now() - 8 * 60000).toISOString(),
    skusAtivos: 342,
    vendasHoje: 18420.5,
    comissaoPercentual: 0.16,
    taxaFixa: 6.75,
    freteMedio: 22.9,
    metas: { margemMinima: 0.12, margemIdeal: 0.22 },
    reputacao: {
      nivel: "excelente",
      rotuloCanal: "MercadoLíder Platinum",
      taxaAtraso: 0.008,
      taxaCancelamento: 0.004,
      taxaReclamacao: 0.006,
      limiteAtraso: 0.15,
      limiteCancelamento: 0.02,
      alerta: null,
    },
  },
  {
    id: "shopee",
    nome: "Shopee",
    conectado: true,
    statusConexao: "conectado",
    ultimaSincronizacao: new Date(Date.now() - 52 * 60000).toISOString(),
    skusAtivos: 298,
    vendasHoje: 9870,
    comissaoPercentual: 0.2,
    taxaFixa: 4,
    freteMedio: 18.5,
    metas: { margemMinima: 0.1, margemIdeal: 0.2 },
    reputacao: {
      nivel: "bom",
      rotuloCanal: "Loja Preferida",
      taxaAtraso: 0.031,
      taxaCancelamento: 0.011,
      taxaReclamacao: 0.014,
      limiteAtraso: 0.05,
      limiteCancelamento: 0.02,
      alerta: null,
    },
  },
  {
    id: "amazon",
    nome: "Amazon",
    conectado: true,
    statusConexao: "conectado",
    ultimaSincronizacao: new Date(Date.now() - 21 * 60000).toISOString(),
    skusAtivos: 210,
    vendasHoje: 11230,
    comissaoPercentual: 0.15,
    taxaFixa: 5.5,
    freteMedio: 19.9,
    metas: { margemMinima: 0.14, margemIdeal: 0.25 },
    reputacao: {
      nivel: "regular",
      rotuloCanal: null,
      taxaAtraso: 0.038,
      taxaCancelamento: 0.019,
      taxaReclamacao: 0.021,
      limiteAtraso: 0.04,
      limiteCancelamento: 0.025,
      alerta: "Taxa de atraso a 0,2 p.p. do limite da conta.",
    },
  },
  {
    id: "magalu",
    nome: "Magalu",
    conectado: true,
    statusConexao: "token-expirando",
    ultimaSincronizacao: new Date(Date.now() - 3 * 3600000).toISOString(),
    skusAtivos: 156,
    vendasHoje: 4120,
    comissaoPercentual: 0.18,
    taxaFixa: 5,
    freteMedio: 20,
    metas: null,
    reputacao: {
      nivel: "em-risco",
      rotuloCanal: "Selo Prata",
      taxaAtraso: 0.062,
      taxaCancelamento: 0.028,
      taxaReclamacao: 0.033,
      limiteAtraso: 0.05,
      limiteCancelamento: 0.02,
      alerta: "Atraso e cancelamento acima do limite — risco de perda do selo.",
    },
  },
  {
    id: "tiktok-shop",
    nome: "TikTok Shop",
    conectado: false,
    statusConexao: "desconectado",
    ultimaSincronizacao: null,
    skusAtivos: 0,
    vendasHoje: 0,
    comissaoPercentual: 0.14,
    taxaFixa: 3.5,
    freteMedio: 15,
    metas: { margemMinima: 0.08, margemIdeal: 0.18 },
    reputacao: null,
  },
  {
    id: "shein",
    nome: "Shein",
    conectado: false,
    statusConexao: "desconectado",
    ultimaSincronizacao: null,
    skusAtivos: 0,
    vendasHoje: 0,
    comissaoPercentual: 0.16,
    taxaFixa: 3,
    freteMedio: 12,
    metas: null,
    reputacao: null,
  },
];

export const getMarketplace = (id: MarketplaceId) =>
  MARKETPLACES.find((m) => m.id === id)!;

interface Produto {
  sku: string;
  nome: string;
  preco: number;
  cmv: number;
}

export const PRODUTOS: Produto[] = [
  { sku: "SW-X-BLK-001", nome: "Smartwatch Series X Titanium Black", preco: 499.9, cmv: 212 },
  { sku: "AU-G3-2026", nome: "Fone Bluetooth Cancelamento de Ruído G3", preco: 289, cmv: 118 },
  { sku: "PWR-GAN-65W", nome: "Carregador Turbo 65W GaN", preco: 189.9, cmv: 74 },
  { sku: "HUB-USBC-7X1", nome: "Hub USB-C 7 em 1 Alumínio", preco: 249.9, cmv: 96 },
  { sku: "PEL-IP15-PM", nome: "Película de Vidro iPhone 15 Pro Max", preco: 39.9, cmv: 8.5 },
  { sku: "CAD-ERG-PRO", nome: "Cadeira Gamer Ergonômica Pro", preco: 1290, cmv: 640 },
  { sku: "TEC-MEC-RGB", nome: "Teclado Mecânico RGB 75%", preco: 359, cmv: 148 },
  { sku: "MON-27-QHD", nome: "Monitor 27'' QHD 165Hz", preco: 1599, cmv: 890 },
  { sku: "CAM-WEB-4K", nome: "Webcam 4K com Microfone Duplo", preco: 429, cmv: 190 },
  { sku: "SSD-1TB-NVME", nome: "SSD NVMe 1TB Gen4", preco: 549, cmv: 288 },
  { sku: "LUM-RING-18", nome: "Ring Light 18'' com Tripé", preco: 219.9, cmv: 82 },
  { sku: "MOU-SF-2K", nome: "Mouse Sem Fio Silencioso 2.4G", preco: 89.9, cmv: 27 },
];

const CLIENTES = [
  "Ana Beatriz Souza",
  "Carlos Eduardo Lima",
  "Juliana Ferreira",
  "Marcos Vinícius Rocha",
  "Patrícia Gomes",
  "Rafael Andrade",
  "Tatiane Moreira",
  "Bruno Carvalho",
  "Letícia Nunes",
  "Diego Martins",
];

const STATUS: StatusPedido[] = [
  "entregue",
  "entregue",
  "entregue",
  "em-transito",
  "aguardando-envio",
  "cancelado",
];

const IMPOSTO_PADRAO = 0.1;
const DIAS_HISTORICO = 120;

function gerarPedidos(): Pedido[] {
  const rand = criarRandom(20260821);
  const pedidos: Pedido[] = [];
  const hoje = new Date();

  for (let d = DIAS_HISTORICO; d >= 0; d--) {
    const data = new Date(hoje);
    data.setDate(hoje.getDate() - d);
    // Tendência de crescimento suave + variação de fim de semana
    const fimDeSemana = data.getDay() === 0 || data.getDay() === 6;
    const base = 9 + Math.round((DIAS_HISTORICO - d) / 22);
    const qtdPedidos = Math.max(
      2,
      Math.round((base + rand() * 6) * (fimDeSemana ? 0.65 : 1)),
    );

    for (let i = 0; i < qtdPedidos; i++) {
      const produto = PRODUTOS[Math.floor(rand() * PRODUTOS.length)]!;
      const marketplace = MARKETPLACES[Math.floor(rand() * 3)]!;
      const quantidade = rand() > 0.82 ? 2 : 1;
      const desconto = rand() > 0.7 ? Math.round(produto.preco * 0.05 * 100) / 100 : 0;
      const precoUnitario = Math.round((produto.preco - desconto) * 100) / 100;
      const faturamento = Math.round(precoUnitario * quantidade * 100) / 100;
      const cmv = Math.round(produto.cmv * quantidade * 100) / 100;
      const comissao = Math.round(faturamento * marketplace.comissaoPercentual * 100) / 100;
      const taxaFixa = marketplace.taxaFixa;
      const impostos = Math.round(faturamento * IMPOSTO_PADRAO * 100) / 100;
      const outrosCustos = Math.round((2 + rand() * 12) * 100) / 100;
      const lucroLiquido =
        Math.round((faturamento - cmv - comissao - taxaFixa - impostos - outrosCustos) * 100) /
        100;
      const status = STATUS[Math.floor(rand() * STATUS.length)]!;
      const clienteIdx = Math.floor(rand() * CLIENTES.length);
      const ddd = 11 + Math.floor(rand() * 78);

      const hora = 8 + Math.floor(rand() * 13);
      const minuto = Math.floor(rand() * 60);
      const dataHora = new Date(data);
      dataHora.setHours(hora, minuto, 0, 0);

      pedidos.push({
        id: `${marketplace.id.slice(0, 3).toUpperCase()}-${(100000 + Math.floor(rand() * 899999)).toString()}`,
        data: dataHora.toISOString(),
        marketplaceId: marketplace.id,
        sku: produto.sku,
        produto: produto.nome,
        quantidade,
        precoUnitario,
        faturamento,
        cmv,
        comissao,
        taxaFixa,
        impostos,
        descontos: Math.round(desconto * quantidade * 100) / 100,
        outrosCustos,
        lucroLiquido,
        margem: faturamento ? lucroLiquido / faturamento : 0,
        status,
        cliente: CLIENTES[clienteIdx]!,
        telefone: `(${ddd}) 9${Math.floor(1000 + rand() * 8999)}-${Math.floor(1000 + rand() * 8999)}`,
      });
    }
  }

  return pedidos.sort((a, b) => +new Date(b.data) - +new Date(a.data));
}

export const PEDIDOS: Pedido[] = gerarPedidos();

/**
 * Gera anúncios deliberadamente imperfeitos: alguns sem custo cadastrado,
 * alguns sem vínculo com produto, alguns no prejuízo, alguns com taxa ainda
 * estimada. Um catálogo real é assim — e a interface precisa aguentar isso.
 */
function gerarAnuncios(): Anuncio[] {
  const rand = criarRandom(777);
  const anuncios: Anuncio[] = [];

  for (const produto of PRODUTOS) {
    for (const marketplace of MARKETPLACES.slice(0, 4)) {
      const sorteio = rand();

      // ~18% do catálogo sem produto vinculado -> sem CMV -> sem margem real
      const produtoVinculado = sorteio > 0.18;
      const cmv = produtoVinculado ? produto.cmv : null;

      // Alguns anúncios com preço agressivo demais para caírem no vermelho
      const agressivo = rand() > 0.82;
      const ajuste = agressivo ? 0.72 + rand() * 0.1 : 1 + (rand() - 0.4) * 0.12;
      const precoAtual = Math.round(produto.preco * ajuste * 100) / 100;

      const emPromocao = rand() > 0.7;
      const precoCheio = emPromocao
        ? Math.round(precoAtual * (1.12 + rand() * 0.15) * 100) / 100
        : null;

      // Frete: só é custo do seller acima do limiar de frete grátis do canal
      const temFreteSubsidiado = precoAtual >= 79;
      const freteUnitario = temFreteSubsidiado
        ? Math.round(marketplace.freteMedio * (0.6 + rand() * 0.6) * 100) / 100
        : 0;

      // ADS: só uma parte do catálogo é impulsionada
      const investeMidia = rand() > 0.6;
      const custoMidiaUnitario = investeMidia
        ? Math.round(precoAtual * (0.02 + rand() * 0.09) * 100) / 100
        : 0;

      // Afiliados: praticamente só no TikTok Shop (lives e criadores)
      const custoAfiliadoUnitario =
        marketplace.id === "tiktok-shop" && rand() > 0.35
          ? Math.round(precoAtual * (0.05 + rand() * 0.1) * 100) / 100
          : 0;

      anuncios.push({
        id: `${marketplace.id}-${produto.sku}`,
        marketplaceId: marketplace.id,
        sku: produto.sku,
        produto: produto.nome,
        precoAtual,
        precoCheio,
        emPromocao,
        cmv,
        impostoPercentual: IMPOSTO_PADRAO,
        comissaoPercentual: marketplace.comissaoPercentual,
        taxaFixa: marketplace.taxaFixa,
        freteUnitario,
        custoMidiaUnitario,
        custoAfiliadoUnitario,
        // Canal recém-conectado ainda não liquidou taxas
        origemTaxas:
          marketplace.statusConexao === "conectado" && rand() > 0.35
            ? "liquidado"
            : "estimado",
        produtoVinculado,
        status: rand() > 0.9 ? "pausado" : rand() > 0.95 ? "sem-estoque" : "ativo",
        elegivelPromocao: rand() > 0.55,
        unidadesVendidas: Math.floor(rand() * rand() * 90),
      });
    }
  }

  return anuncios;
}

export const ANUNCIOS: Anuncio[] = gerarAnuncios();

export const HISTORICO_PRECOS: AlteracaoPreco[] = [
  {
    id: "hp-1",
    data: new Date(Date.now() - 3 * 3600000).toISOString(),
    sku: "SW-X-BLK-001",
    produto: "Smartwatch Series X Titanium Black",
    marketplaceId: "mercado-livre",
    precoAnterior: 479.9,
    precoNovo: 499.9,
    usuario: "Felipe Camargo",
  },
  {
    id: "hp-2",
    data: new Date(Date.now() - 26 * 3600000).toISOString(),
    sku: "PEL-IP15-PM",
    produto: "Película de Vidro iPhone 15 Pro Max",
    marketplaceId: "shopee",
    precoAnterior: 44.9,
    precoNovo: 39.9,
    usuario: "Marina Alves",
  },
  {
    id: "hp-3",
    data: new Date(Date.now() - 50 * 3600000).toISOString(),
    sku: "TEC-MEC-RGB",
    produto: "Teclado Mecânico RGB 75%",
    marketplaceId: "amazon",
    precoAnterior: 339,
    precoNovo: 359,
    usuario: "Felipe Camargo",
  },
  {
    id: "hp-4",
    data: new Date(Date.now() - 74 * 3600000).toISOString(),
    sku: "MON-27-QHD",
    produto: "Monitor 27'' QHD 165Hz",
    marketplaceId: "mercado-livre",
    precoAnterior: 1699,
    precoNovo: 1599,
    usuario: "Rodrigo Peixoto",
  },
];

export const PROMOCOES: Promocao[] = PRODUTOS.slice(0, 7).map((produto, i) => {
  const rebate = Math.round(produto.preco * (0.04 + i * 0.008) * 100) / 100;
  const desconto = Math.round(produto.preco * (0.1 + i * 0.01) * 100) / 100;
  return {
    id: `promo-${produto.sku}`,
    marketplaceId: "mercado-livre",
    sku: produto.sku,
    produto: produto.nome,
    precoAtual: produto.preco,
    tipo: i % 3 === 0 ? "Oferta do Dia" : i % 3 === 1 ? "Campanha Semana Tech" : "Promoção Relâmpago",
    rebate,
    precoFinal: Math.round((produto.preco - desconto + rebate) * 100) / 100,
    cmv: produto.cmv,
    impostoPercentual: IMPOSTO_PADRAO,
    comissaoPercentual: 0.16,
    taxaFixa: 6.75,
  };
});

export const ESTOQUE: ItemEstoque[] = PRODUTOS.map((produto, i) => ({
  sku: produto.sku,
  produto: produto.nome,
  marketplaceId: MARKETPLACES[i % 3]!.id,
  estoqueAtual: [12, 320, 145, 60, 45, 18, 210, 95, 33, 410, 78, 640][i] ?? 100,
  estoqueFulfillment: [4, 180, 60, 22, 12, 6, 120, 40, 15, 260, 30, 380][i] ?? 50,
}));

export const NOTIFICACOES: Notificacao[] = [
  {
    id: "n1",
    tipo: "promocao",
    titulo: "Nova promoção disponível",
    descricao: "Mercado Livre abriu a campanha \"Semana Tech\". 7 anúncios elegíveis.",
    data: new Date(Date.now() - 12 * 60000).toISOString(),
    lida: false,
  },
  {
    id: "n2",
    tipo: "sincronizacao",
    titulo: "Sincronização concluída",
    descricao: "Amazon sincronizada com sucesso. 142 SKUs atualizados.",
    data: new Date(Date.now() - 70 * 60000).toISOString(),
    lida: false,
  },
  {
    id: "n3",
    tipo: "desconexao",
    titulo: "Marketplace desconectado",
    descricao: "A conexão com o Magalu ainda não foi configurada.",
    data: new Date(Date.now() - 6 * 3600000).toISOString(),
    lida: true,
  },
  {
    id: "n4",
    tipo: "erro",
    titulo: "Erro de sincronização",
    descricao: "Não foi possível ler 3 anúncios da Shopee. Tentaremos novamente.",
    data: new Date(Date.now() - 9 * 3600000).toISOString(),
    lida: true,
  },
  {
    id: "n5",
    tipo: "configuracao",
    titulo: "Alteração de configuração",
    descricao: "Alíquota de imposto alterada de 8% para 10% por Felipe Camargo.",
    data: new Date(Date.now() - 30 * 3600000).toISOString(),
    lida: true,
  },
];

export const USUARIOS: Usuario[] = [
  {
    id: "u1",
    nome: "Felipe Camargo",
    email: "felipe@nexuscommerce.com.br",
    papel: "administrador",
    ativo: true,
    ultimoAcesso: new Date(Date.now() - 20 * 60000).toISOString(),
  },
  {
    id: "u2",
    nome: "Marina Alves",
    email: "marina@nexuscommerce.com.br",
    papel: "analista",
    ativo: true,
    ultimoAcesso: new Date(Date.now() - 4 * 3600000).toISOString(),
  },
  {
    id: "u3",
    nome: "Rodrigo Peixoto",
    email: "rodrigo@nexuscommerce.com.br",
    papel: "operacional",
    ativo: true,
    ultimoAcesso: new Date(Date.now() - 28 * 3600000).toISOString(),
  },
  {
    id: "u4",
    nome: "Camila Duarte",
    email: "camila@nexuscommerce.com.br",
    papel: "operacional",
    ativo: false,
    ultimoAcesso: new Date(Date.now() - 20 * 24 * 3600000).toISOString(),
  },
];

export const LOGS: LogAlteracao[] = [
  {
    id: "l1",
    data: new Date(Date.now() - 3 * 3600000).toISOString(),
    usuario: "Felipe Camargo",
    acao: "Alteração de preço — SW-X-BLK-001",
    valorAnterior: "R$ 479,90",
    valorNovo: "R$ 499,90",
  },
  {
    id: "l2",
    data: new Date(Date.now() - 26 * 3600000).toISOString(),
    usuario: "Marina Alves",
    acao: "Alteração de preço — PEL-IP15-PM",
    valorAnterior: "R$ 44,90",
    valorNovo: "R$ 39,90",
  },
  {
    id: "l3",
    data: new Date(Date.now() - 30 * 3600000).toISOString(),
    usuario: "Felipe Camargo",
    acao: "Regra financeira — Alíquota de imposto",
    valorAnterior: "8%",
    valorNovo: "10%",
  },
  {
    id: "l4",
    data: new Date(Date.now() - 54 * 3600000).toISOString(),
    usuario: "Rodrigo Peixoto",
    acao: "Permissão de usuário — Camila Duarte",
    valorAnterior: "Analista",
    valorNovo: "Operacional",
  },
  {
    id: "l5",
    data: new Date(Date.now() - 100 * 3600000).toISOString(),
    usuario: "Felipe Camargo",
    acao: "Margem desejada padrão",
    valorAnterior: "18%",
    valorNovo: "22%",
  },
];

export const EMPRESA = {
  nome: "Nexus Commerce LTDA",
  cnpj: "42.918.774/0001-06",
  regime: "Simples Nacional",
  plano: "Plano Enterprise",
  email: "financeiro@nexuscommerce.com.br",
  telefone: "(11) 4002-8922",
  endereco: "Av. Paulista, 1578 — São Paulo/SP",
};

export const USUARIO_ATUAL = USUARIOS[0]!;

export const REGRAS_FINANCEIRAS = {
  impostoPercentual: IMPOSTO_PADRAO,
  margemDesejada: 0.22,
  outrosCustosPadrao: 0,
};

const TIPOS_RECUPERACAO: TipoOportunidadeRecuperacao[] = [
  "boleto-pendente",
  "pix-nao-pago",
  "cancelamento-solicitado",
];
const CANAIS_RECUPERACAO: CanalRecuperacao[] = ["whatsapp", "email", "sms"];

function gerarOportunidadesRecuperacao(): OportunidadeRecuperacao[] {
  const rand = criarRandom(20260915);
  const alvos = { total: 38450, recuperado: 14210 };

  const oportunidades: OportunidadeRecuperacao[] = [];
  for (let i = 0; i < 67; i++) {
    const recuperado = i < 25;
    const status: StatusOportunidadeRecuperacao = recuperado
      ? "recuperado"
      : i < 55
        ? "aguardando-acao"
        : "mensagem-enviada";
    const tipo = TIPOS_RECUPERACAO[Math.floor(rand() * TIPOS_RECUPERACAO.length)]!;
    const canal = CANAIS_RECUPERACAO[Math.floor(rand() * CANAIS_RECUPERACAO.length)]!;
    const marketplace = MARKETPLACES[Math.floor(rand() * 3)]!;
    const produto = PRODUTOS[Math.floor(rand() * PRODUTOS.length)]!;
    const cliente = CLIENTES[Math.floor(rand() * CLIENTES.length)]!;
    const valor = Math.round((200 + rand() * 800) * 100) / 100;
    const horas = Math.floor(1 + rand() * 47);

    oportunidades.push({
      id: `REC-${1000 + i}`,
      cliente,
      pedidoId: `${marketplace.id.slice(0, 3).toUpperCase()}-${(100000 + Math.floor(rand() * 899999)).toString()}`,
      marketplaceId: marketplace.id,
      valor,
      tipo,
      tempoRestante: recuperado ? "—" : `${horas}h`,
      status,
      canal,
      dataCriacao: new Date(Date.now() - Math.floor(rand() * 10 * 24 * 3600000)).toISOString(),
      dataUltimoContato: recuperado
        ? new Date(Date.now() - Math.floor(rand() * 5 * 24 * 3600000)).toISOString()
        : null,
    });
  }

  const somaTotal = oportunidades.reduce((acc, o) => acc + o.valor, 0);
  const somaRecuperado = oportunidades
    .filter((o) => o.status === "recuperado")
    .reduce((acc, o) => acc + o.valor, 0);
  const somaPendente = somaTotal - somaRecuperado;

  const fatorRecuperado = alvos.recuperado / somaRecuperado;
  const fatorPendente = (alvos.total - alvos.recuperado) / somaPendente;

  for (const o of oportunidades) {
    const fator = o.status === "recuperado" ? fatorRecuperado : fatorPendente;
    o.valor = Math.round(o.valor * fator * 100) / 100;
  }

  return oportunidades.sort((a, b) => +new Date(b.dataCriacao) - +new Date(a.dataCriacao));
}

export const OPORTUNIDADES_RECUPERACAO: OportunidadeRecuperacao[] =
  gerarOportunidadesRecuperacao();

export const CANAIS_NOTIFICACAO: CanalNotificacao[] = [
  {
    id: "whatsapp",
    nome: "WhatsApp",
    icone: "MessageCircle",
    conectado: true,
    disparosAutomaticos: true,
    ultimoDisparo: new Date(Date.now() - 12 * 60000).toISOString(),
    taxaAbertura: 0.78,
    custoEstimado: 0.08,
  },
  {
    id: "email",
    nome: "E-mail",
    icone: "Mail",
    conectado: true,
    disparosAutomaticos: false,
    ultimoDisparo: new Date(Date.now() - 3 * 3600000).toISOString(),
    taxaAbertura: 0.42,
    custoEstimado: 0.02,
  },
  {
    id: "sms",
    nome: "SMS",
    icone: "Smartphone",
    conectado: false,
    disparosAutomaticos: false,
    ultimoDisparo: new Date(Date.now() - 2 * 24 * 3600000).toISOString(),
    taxaAbertura: 0.65,
    custoEstimado: 0.12,
  },
];


// ---------------------------------------------------------------------------
// Estoque detalhado (cobertura em dias). Dados fictícios com números realistas.
// ---------------------------------------------------------------------------

const ESTOQUE_QTD = [8, 320, 145, 0, 45, 18, 210, 95, 0, 410, 78, 640];
const ESTOQUE_VENDAS_DIA = [2.4, 4.1, 9.8, 1.2, 6.5, 0.4, 7.2, 2.1, 1.8, 3.4, 0.9, 12.5];

export const ESTOQUE_DETALHADO: ItemEstoqueDetalhado[] = PRODUTOS.map((produto, i) => {
  const quantidade = ESTOQUE_QTD[i] ?? 100;
  const vendasDia = ESTOQUE_VENDAS_DIA[i] ?? 2;
  const cobertura = vendasDia > 0 ? Math.round(quantidade / vendasDia) : 0;
  return {
    sku: produto.sku,
    produto: produto.nome,
    marketplaceId: MARKETPLACES[i % 3]!.id,
    quantidade,
    vendasDia,
    coberturaDias: cobertura,
    custoUnitario: produto.cmv,
    valorEstoque: Math.round(quantidade * produto.cmv * 100) / 100,
  };
});

/** Resumo consolidado da operação (considera os 142 SKUs ativos da conta). */
export const RESUMO_ESTOQUE = {
  /** CMV total das unidades paradas em estoque */
  capitalInvestido: 185200,
  skusAtivos: 142,
  /** SKUs com menos de 10 unidades disponíveis */
  skusRuptura: ESTOQUE_DETALHADO.filter((i) => i.quantidade > 0 && i.quantidade < 10).length || 5,
  valorParado: 12400,
  /** Unidades paradas (cobertura acima de 60 dias) */
  unidadesParadas:
    ESTOQUE_DETALHADO.filter((i) => i.coberturaDias > 60).reduce(
      (t, i) => t + i.quantidade,
      0,
    ) || 485,
};

// ---------------------------------------------------------------------------
// Fulfillment (estoque alocado nos galpões dos marketplaces). Dados fictícios.
// ---------------------------------------------------------------------------

const FULL_QTD = [4, 180, 60, 0, 12, 6, 120, 40, 0, 260, 30, 380];
const FULL_VENDAS_DIA = [1.8, 3.2, 7.4, 0.9, 5.1, 0.3, 6.0, 1.6, 1.2, 2.6, 0.5, 9.8];

export const FULFILLMENT_DETALHADO: ItemEstoqueDetalhado[] = PRODUTOS.map((produto, i) => {
  const quantidade = FULL_QTD[i] ?? 40;
  const vendasDia = FULL_VENDAS_DIA[i] ?? 1.5;
  const cobertura = vendasDia > 0 ? Math.round(quantidade / vendasDia) : 0;
  return {
    sku: produto.sku,
    produto: produto.nome,
    marketplaceId: MARKETPLACES[i % 3]!.id,
    quantidade,
    vendasDia,
    coberturaDias: cobertura,
    custoUnitario: produto.cmv,
    valorEstoque: Math.round(quantidade * produto.cmv * 100) / 100,
  };
});

/** Resumo consolidado do fulfillment. */
export const RESUMO_FULFILLMENT = {
  /** CMV total das unidades alocadas nos galpões */
  capitalInvestido: 92400,
  /** SKUs com estoque alocado em fulfillment */
  skusFull: FULFILLMENT_DETALHADO.filter((i) => i.quantidade > 0).length,
  /** SKUs com menos de 10 unidades no galpão */
  skusRuptura: FULFILLMENT_DETALHADO.filter((i) => i.quantidade > 0 && i.quantidade < 10).length,
  /** Unidades paradas (cobertura acima de 60 dias) */
  unidadesParadas:
    FULFILLMENT_DETALHADO.filter((i) => i.coberturaDias > 60).reduce(
      (t, i) => t + i.quantidade,
      0,
    ) || 320,
};
